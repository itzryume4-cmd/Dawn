package dev.dawnlite;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class DawnLiteClient implements ClientModInitializer {
    public static KeyBinding zoomKey;
    public static KeyBinding menuKey;

    private static double zoomCur = 1.0;
    private static long zoomNs = 0;

    public static boolean isZooming() {
        return zoomKey != null && zoomKey.isPressed();
    }

    /** Pengali FOV (1.0 = normal). Dipanggil dari mixin GameRenderer. */
    public static double zoomMultiplier() {
        DawnConfig c = DawnConfig.get();
        long now = System.nanoTime();
        double dt = zoomNs == 0 ? 0 : (now - zoomNs) / 1e9;
        zoomNs = now;
        dt = Math.min(dt, 0.1);
        double target = (c.zoom && isZooming()) ? c.zoomPct / 100.0 : 1.0;
        if (c.smoothZoom) {
            zoomCur += (target - zoomCur) * Math.min(1.0, dt * 12.0);
            if (Math.abs(zoomCur - target) < 0.001) zoomCur = target;
        } else {
            zoomCur = target;
        }
        return zoomCur;
    }

    private static boolean fakeNightVision(ClientPlayerEntity p) {
        StatusEffectInstance e = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        return e != null && e.getDuration() > 900000;
    }

    private static void tickFullbright(ClientPlayerEntity p) {
        boolean has = fakeNightVision(p);
        if (DawnConfig.get().fullbright) {
            if (!has) {
                p.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, Widgets.FAKE_NV_TICKS, 0, false, false, false));
            }
        } else if (has) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onInitializeClient() {
        DawnConfig.load();

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.dawnlite"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.dawnlite"));

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> Optimizer.apply(client));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new DawnMenuScreen(client.currentScreen));
            }
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            tickFullbright(p);
            if (DawnConfig.get().autoSprint
                    && client.currentScreen == null
                    && client.options.forwardKey.isPressed()
                    && !p.isSneaking()
                    && !p.horizontalCollision
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        });

        HudRenderCallback.EVENT.register(DawnHud::render);

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen || screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("DawnLite"),
                                        b -> MinecraftClient.getInstance().setScreen(new DawnMenuScreen(screen)))
                                .dimensions(4, 4, 70, 20).build());
            }
        });
    }
}
