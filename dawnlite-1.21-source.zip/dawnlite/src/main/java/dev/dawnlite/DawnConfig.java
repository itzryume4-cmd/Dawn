package dev.dawnlite;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class DawnConfig {
    // ===== HUD =====
    public boolean fps = true;
    public boolean cps = true;
    public boolean ping = true;
    public boolean coords = true;
    public boolean direction = false;
    public boolean speed = false;
    public boolean memory = false;
    public boolean clock = false;
    public boolean day = false;
    public boolean server = false;
    public boolean keystrokes = true;
    public boolean armor = true;
    public boolean potions = true;
    public boolean hudBackground = true;
    public int hudOpacity = 45;
    public int accent = 0;

    // ===== Gameplay =====
    public boolean fullbright = false;
    public boolean autoSprint = false;
    public boolean zoom = true;
    public boolean smoothZoom = true;
    public int zoomPct = 25;

    // ===== Optimizer =====
    public boolean optGraphics = false;
    public boolean optParticles = false;
    public boolean optClouds = false;
    public boolean optEntityDist = false;
    public boolean optShadows = false;
    public boolean optBiome = false;
    public boolean optFps = false;
    public boolean optVsync = false;
    public boolean optDistance = false;

    public Map<String, int[]> pos = new HashMap<>();
    public Map<String, String> origs = new HashMap<>();

    public static final int[] ACCENTS = {
            0x4F8CFF, 0xFF5C8A, 0x4ADE80, 0xFBBF24, 0xA78BFA, 0x22D3EE, 0xF97316, 0xE5E7EB
    };

    private static DawnConfig instance = new DawnConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("dawnlite.json");
    }

    public static DawnConfig get() { return instance; }

    public static int accentColor() {
        return 0xFF000000 | ACCENTS[Math.floorMod(instance.accent, ACCENTS.length)];
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                DawnConfig c = GSON.fromJson(Files.readString(p), DawnConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {}
        if (instance.pos == null) instance.pos = new HashMap<>();
        if (instance.origs == null) instance.origs = new HashMap<>();
        save();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception ignored) {}
    }
}
